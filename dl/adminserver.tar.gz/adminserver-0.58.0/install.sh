#!/usr/bin/env bash
# AdminServer installer. Safe to run again to upgrade: configuration, users
# and data are kept.
#
#   sudo ./install.sh                 install on the default port 8443
#   sudo PANEL_PORT=9443 ./install.sh choose another port (first install only)
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BIN=/usr/local/bin/adminserver
DATA=/var/lib/adminserver
SVC_USER=adminserver

die() { echo "خطأ / Error: $*" >&2; exit 1; }

[ "$(id -u)" -eq 0 ] || die "شغّل المنصِّب بصلاحيات root / run as root (sudo ./install.sh)"
command -v systemctl >/dev/null || die "systemd is required"

. /etc/os-release
major="${VERSION_ID%%.*}"
case " ${ID:-} ${ID_LIKE:-} " in
  *" rhel "*|*" fedora "*|*" centos "*) ;;
  *) [ "${FORCE:-0}" = 1 ] || die "نظام غير مدعوم (${PRETTY_NAME}). المدعوم: AlmaLinux / Rocky / RHEL 9 و 10. / Unsupported system; set FORCE=1 to try anyway." ;;
esac
case "$major" in
  9|10) ;;
  *) [ "${FORCE:-0}" = 1 ] || die "إصدار غير مدعوم (${VERSION_ID}). / Unsupported release; set FORCE=1 to try anyway." ;;
esac

case "$(uname -m)" in
  x86_64)  arch=amd64 ;;
  aarch64) arch=arm64 ;;
  *) die "unsupported CPU: $(uname -m)" ;;
esac
SRC="$HERE/bin/adminserver-linux-$arch"
[ -f "$SRC" ] || die "missing $SRC"

echo "==> AdminServer $("$SRC" version)"

id "$SVC_USER" >/dev/null 2>&1 || useradd --system --home-dir "$DATA" --no-create-home --shell /sbin/nologin "$SVC_USER"

systemctl stop adminserver-web adminserver-agent 2>/dev/null || true
install -m 0755 "$SRC" "$BIN"
install -m 0644 "$HERE/systemd/adminserver-agent.service" "$HERE/systemd/adminserver-web.service" /etc/systemd/system/
command -v restorecon >/dev/null && restorecon "$BIN" /etc/systemd/system/adminserver-*.service || true

# Prints the one-time admin password on a first install, nothing on upgrade.
CREDS="$(ADMINSERVER_PORT="${PANEL_PORT:-}" "$BIN" init)"

chown root:root "$DATA" "$DATA/agent"
chmod 0755 "$DATA"; chmod 0700 "$DATA/agent"
chown -R "$SVC_USER:$SVC_USER" "$DATA/data"
chmod 0750 "$DATA/data"

PORT="$(sed -n 's/.*"port": *\([0-9]*\).*/\1/p' /etc/adminserver/config.json)"

systemctl daemon-reload
systemctl enable --now adminserver-agent adminserver-web >/dev/null

# phpMyAdmin is proxied on its own port (the panel's port + 1 by default).
PMA_PORT="$(sed -n 's/.*"pma_port": *\([0-9]*\).*/\1/p' /etc/adminserver/config.json)"
PMA_PORT="${PMA_PORT:-$((PORT + 1))}"

if systemctl is-active --quiet firewalld; then
  firewall-cmd --quiet --permanent --add-port="$PORT/tcp"
  firewall-cmd --quiet --permanent --add-port="$PMA_PORT/tcp"
  firewall-cmd --quiet --reload
fi

sleep 1
systemctl is-active --quiet adminserver-web || die "اللوحة لم تعمل / the panel did not start: journalctl -u adminserver-web"

IP="$(hostname -I 2>/dev/null | awk '{print $1}')"
# Once the panel is tied to a domain it answers under that name only.
DOMAIN="$(sed -n 's/.*"domain": *"\([^"]*\)".*/\1/p' /etc/adminserver/config.json)"
echo
echo "============================================================"
echo "  تم تنصيب AdminServer / AdminServer is installed"
echo
echo "  https://${DOMAIN:-${IP:-SERVER_IP}}:$PORT"
if [ -n "$CREDS" ]; then
  echo
  echo "  المستخدم / User:         $(sed -n 's/^ADMIN_USER=//p' <<<"$CREDS")"
  echo "  كلمة المرور / Password:  $(sed -n 's/^ADMIN_PASSWORD=//p' <<<"$CREDS")"
  echo
  echo "  كلمة المرور لمرة واحدة وستُطلب منك كلمة جديدة عند أول دخول."
  echo "  One-time password: you will choose a new one at first sign-in."
fi
if [ -z "$DOMAIN" ]; then
  echo
  echo "  الشهادة موقّعة ذاتيًا، فسيعرض المتصفح تحذيرًا عند أول زيارة."
  echo "  The certificate is self-signed, so the browser warns on first visit."
  echo
  echo "  أول ما تفعله: افتح «الحماية» وأعطِ اللوحة نطاقًا خاصًا (شهادة موثوقة"
  echo "  ويُغلق عنوان IP)، وفعّل التحقق بخطوتين، ثم «طبّق كل التوصيات الآمنة»."
  echo "  First thing: open Security, give the panel a domain of its own (trusted"
  echo "  certificate, the IP address closes), turn on two-step sign-in, then"
  echo "  \"Apply all safe recommendations\"."
fi
echo "============================================================"
