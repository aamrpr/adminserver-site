#!/usr/bin/env bash
# Removes the panel. Hardening it applied to the server stays in place.
#   sudo ./uninstall.sh          keep data in /var/lib/adminserver
#   sudo ./uninstall.sh --purge  also delete configuration, users and logs
set -euo pipefail
[ "$(id -u)" -eq 0 ] || { echo "run as root" >&2; exit 1; }

systemctl disable --now adminserver-web adminserver-agent 2>/dev/null || true
rm -f /etc/systemd/system/adminserver-agent.service /etc/systemd/system/adminserver-web.service
systemctl daemon-reload
rm -f /usr/local/bin/adminserver

# Postfix asks the agent's mail filter about every message and holds mail
# while it is away; with the agent gone for good it must stop asking.
if command -v postconf >/dev/null 2>&1 && postconf -h smtpd_milters 2>/dev/null | grep -q '127.0.0.1:8893'; then
  postconf -e "smtpd_milters=inet:127.0.0.1:8891" "non_smtpd_milters=inet:127.0.0.1:8891"
  postfix reload 2>/dev/null || true
fi
if command -v semodule >/dev/null 2>&1; then semodule -r adminserver_mail 2>/dev/null || true; fi

if [ "${1:-}" = "--purge" ]; then
  rm -rf /var/lib/adminserver /etc/adminserver
  userdel adminserver 2>/dev/null || true
  echo "AdminServer and its data were removed."
else
  echo "AdminServer was removed. Data kept in /var/lib/adminserver (use --purge to delete)."
fi
